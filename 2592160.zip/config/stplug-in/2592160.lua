addappid(2592160)
addappid(2592161, 1, "5b4a3a4477e47584b99200004c6f4ef8cf41be05df586de9e1771e160fc7527d")
setManifestid(2592161, "3546851175359519951", 3329981902)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3920280)
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
