addappid(2958130, 1, "28c45829d1af12623b4fead679e384291bfb040d0241fc6be9d05f7d4cdbbd62")
addappid(2958131, 1, "dc7cb4cb8d7d76fdcab84fed34fa1f799e7459cf1be5ed041116ed846211889d")
setManifestid(2958131, "6616524064629033442", 21349093879)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "3514306556860204959", 39590283)
addappid(3651190)
addappid(3651200)
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
