addappid(3949040)
addappid(3949041, 1, "98435e5f712a11c88e455130e718254b2745a33f7443b2034d634f54af0da031")
setManifestid(3949041, "6517539211333007290", 3343837412)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 102931551)
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
